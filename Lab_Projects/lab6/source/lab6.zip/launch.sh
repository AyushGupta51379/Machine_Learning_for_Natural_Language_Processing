#!/bin/bash
#PBS -N lab6
#PBS -e ./error_log.txt
#PBS -o ./outptu_log.txt
cd ~/lab6
echo Starting calculation
python lab6_answer.py
echo End of calculation

