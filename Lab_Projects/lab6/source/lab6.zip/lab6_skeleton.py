import numpy as np
import string
import pandas as pd
import nltk
import keras

from sklearn import random_projection
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from nltk.corpus import stopwords

from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import SGD
from keras import metrics

stop_words = set(stopwords.words('english') + list(string.punctuation))


# -------------- Helper Functions --------------
def tokenize(text):
    '''
    :param text: a doc with multiple sentences, type: str
    return a word list, type: list
    https://textminingonline.com/dive-into-nltk-part-ii-sentence-tokenize-and-word-tokenize
    e.g.
    Input: 'It is a nice day. I am happy.'
    Output: ['it', 'is', 'a', 'nice', 'day', 'i', 'am', 'happy']
    '''
    tokens = []
    # YOUR CODE HERE
    for word in nltk.word_tokenize(text):
        word = word.lower()
        if word not in stop_words and not word.isnumeric():
            tokens.append(word)
    return tokens


def get_bagofwords(data, vocab_dict):
    '''
    :param data: a list of words, type: list
    :param vocab_dict: a dict from words to indices, type: dict
    return a dense word matrix,
    '''
    data_matrix = np.zeros((len(data), len(vocab_dict)), dtype=float)
    for i, doc in enumerate(data):
        for word in doc:
            word_idx = vocab_dict.get(word, -1)
            if word_idx != -1:
                data_matrix[i, word_idx] += 1
    return data_matrix


def read_data(file_name, vocab=None):
    """
    https://pandas.pydata.org/pandas-docs/stable/generated/pandas.read_csv.html
    """
    df = pd.read_csv(file_name)
    df['words'] = df['text'].apply(tokenize)

    if vocab is None:
        vocab = set()
        for i in range(len(df)):
            for word in df.iloc[i]['words']:
                vocab.add(word)
    vocab_dict = dict(zip(vocab, range(len(vocab))))

    data_matrix = get_bagofwords(df['words'], vocab_dict)

    return df['id'], df['label']-1, data_matrix, vocab
# ----------------- End of Helper Functions-----------------


def load_data():
    # Load training data and vocab
    (train_id_list, train_data_label,
     train_data_matrix, vocab) = read_data("data/train.csv")
    # Load testing data
    test_id_list, _, test_data_matrix, _ = read_data("data/test.csv", vocab)
    test_data_label = pd.read_csv("data/answer.csv")['label'] - 1

    print("Vocabulary Size:", len(vocab))
    print("Training Set Size:", len(train_id_list))
    print("Test Set Size:", len(test_id_list))

    K = max(train_data_label)+1  # labels begin with 0

    # Data random projection
    rand_proj_transformer = random_projection.GaussianRandomProjection(
        eps=0.1)
    # YOUR CODE HERE



    print("Training Set Shape:", train_data_matrix.shape)
    print("Testing Set Shape:", test_data_matrix.shape)

    # Converts a class vector to binary class matrix.
    # YOUR CODE HERE


    return (train_data_matrix, train_data_label,
            test_data_matrix, test_data_label)


if __name__ == '__main__':
    (train_data_matrix, train_data_label,
     test_data_matrix, test_data_label) = load_data()

    # YOUR CODE HERE
    # Data shape, N: data len, V: vocab size, K: label size
    N, V, K = 0, 0, 0

    # Hyperparameters
    input_size = 0
    output_size = 0
    batch_size = 0
    optimizer = SGD
    learning_rate = 0
    total_epoch = 0

    # New model

    # first hidder layer

    # second hidden layer

    # output layer


    # optimizer

    # compile model

    # training

    # testing
    train_score =  [0,0]
    test_score = [0,0]

    print('Training Loss: {}\n Training Accuracy: {}\n'
          'Testng Loss: {}\n Testing accuracy: {}'.format(
              train_score[0], train_score[1],
              test_score[0], test_score[1]))
